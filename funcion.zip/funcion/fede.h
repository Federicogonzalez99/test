int  sumar(int,int);

int sumar(int a, int b){
    int resultado;
    resultado=a + b;
    return resultado;
    }
