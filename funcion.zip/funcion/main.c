#include <stdio.h>
#include <stdlib.h>
#include "fede.h"
int main()
{
    int rta;
    int x=5;
    int y=7;

    rta= sumar(x,y);
    printf("La suma es %d\n",rta);
    return 0;
}


