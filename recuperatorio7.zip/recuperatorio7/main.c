#include <stdio.h>
#include <stdlib.h>

int main()
{
    int nota;
    int edad;
    char sexo;
    int acumNota=0;
    int contador=0;
    float promedioNota;
    int flag=0;
    int notaMin;
    char sexoMin;
    int contVarones=0;
    int edadMin;
    for(int i=0; i<5; i++)
    {
        printf("Ingrese una nota: ");
        scanf("%d",&nota);
        while(nota<0||nota>10)
        {
            printf("Error.Ingrese una nota: ");
            scanf("%d", &nota);
        }
        printf("Ingrese una edad: ");
        scanf("%d", &edad);
        while(edad < 0)
        {
            printf("Edad incorrecta. Ingrese una edad: ");
            scanf("%d", &edad);
        }
        printf("Ingrese un sexo (f o m):");
        fflush(stdin);
        scanf("%c",&sexo);
        sexo=tolower(sexo);
        while(sexo!='f'&& sexo!='m')
        {
            printf("Sexo invalido. Ingrese (f o m): ");
            fflush(stdin);
            scanf("%c",&sexo);
            sexo=tolower(sexo);
        }

        if (flag==0)
        {
            flag=1;
            notaMin=nota;
            sexoMin=sexo;
        }
        if (nota<notaMin)
        {
            notaMin=nota;
            sexoMin=sexo;
        }
        if(edad>18 && nota>=6)
        {
            contVarones++;
        }
        if(flag==0)
        {
            flag=1;
            edadMin=edad;
            notaMin=nota;
            sexoMin=sexo;
        }
        if(edad<edadMin)
        {
            edadMin=edad;
            notaMin=nota;
            sexoMin=sexo;
        }



        acumNota=acumNota+nota;
        promedioNota=(float)acumNota/5;
    }
    /*a*/printf("El promedio de las notas es: %f\n",promedioNota);
    /*b*/printf("La nota mas baja es: %d y el sexo es:%c\n",notaMin, sexoMin);
    /*c*/printf("La cantidad de varones que su edad fue >18 y nota >=6 %d\n",contVarones);
    /*d*/printf("La nota del mas joven es: %d y su sexo es: %c\n",notaMin,sexoMin);
    /*e*/
    return 0;
}
